Deployment: https://www.youtube.com/watch?v=jS4aFq5-91M&t=13395s
            5:46:32


let myLeads2 = `["www.facebook.com"]`

// 1. Turn the myleads2 string into an array
myLeads2 = JSON.parse(myLeads2)
// 2. Push a new value to the array
myLeads2.push("www.face.com")
// 3. Turn the array into a string again
myLeads2 = JSON.stringify(myLeads2)
// 4. Console.log the string using typeof to verify that it's a string
console.log(typeof myLeads2);


