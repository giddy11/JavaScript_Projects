const saveBtn = document.getElementById("input-btn")
const delBtn = document.getElementById("delete-btn")
const tabBtn = document.getElementById("tab-btn")

const inputEl = document.getElementById("input-el")
let ulEl = document.getElementById("ul-el")
let container = document.getElementById("container")
const buyBtn = document.getElementById("buy-btn")

let myLeads = []
let listItems = ""
const leadsFromLocalStorage = JSON.parse(localStorage.getItem("myLeads"))
// const tabs = [
//     {url: "https://www.facebook.com"}
// ]

console.log(leadsFromLocalStorage);

if (leadsFromLocalStorage){
    myLeads = leadsFromLocalStorage
    render(myLeads)
}

function render(leads){
    listItems = ""
    for (let i = 0; i < leads.length; i++){
        listItems += `
            <li>
                <a target='_blank' href='${leads[i]}'>
                    ${leads[i]}
                </a>
            </li>
        `
    }
    ulEl.innerHTML = listItems
}

saveBtn.addEventListener("click", function(){
    myLeads.push(inputEl.value)
    inputEl.value = ""
    localStorage.setItem("myLeads", JSON.stringify(myLeads))
    render(myLeads)
    console.log(localStorage.getItem("myLeads"));
})

delBtn.addEventListener("click", function(){
    localStorage.clear()
    myLeads = []
    render(myLeads)
})

tabBtn.addEventListener("click", function(){
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs){
        myLeads.push(tabs[0].url)
        localStorage.setItem("myLeads", JSON.stringify(myLeads))
        render(myLeads)
    })
})

function buy(){
    container.innerHTML += "<p>Thank you<p/>"
    console.log(9);
}